# PRIVATE AI v1.0 — APK build package

This repository is prepared for a real Android cloud build. It does **not** contain a precompiled APK or a GGUF model.

## Build
Use the included GitHub Actions workflow. It installs JDK 17, Android API 34, NDK 26.1.10909125, CMake 3.22.1, Gradle 8.7, fetches llama.cpp tag `b3600`, and runs `gradle clean assembleDebug`.

The successful workflow artifact contains:
- `PrivateAI-v1.0-debug.apk` — installable debug APK
- `PrivateAI-v1.0.sha256` — checksum

## Important fixes
- Added the Compose Material Icons dependency required by `Icons.Filled.Send`.
- Fixed model import: Android Storage Access Framework `content://` URIs are now copied into the app's private external-files `models/` directory before JNI/llama.cpp receives the path.
- Removed the broken assumption that a SAF URI `.path` is a usable filesystem path.
- Added `gradle.properties` for AndroidX and stable Gradle memory settings.
- Made the cloud workflow bootstrap Gradle directly instead of assuming a pre-existing Gradle wrapper.

## Device/model
The project targets Android 8.0+ (API 26) and arm64-v8a. For a low-memory phone, use a small GGUF instruct model (roughly 0.5B–1B parameters, Q4-class quantization). The model is imported locally after installation.

## Verification
A green GitHub Actions run is the authoritative build verification. This sandbox does not have the Android SDK/NDK toolchain, so I am not claiming that an APK was compiled here.
