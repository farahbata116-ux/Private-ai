# Keep JNI-called methods and native bridge intact.
-keep class com.waalduhaa.privateai.llm.LlamaBridge { *; }
-keepclassmembers class com.waalduhaa.privateai.llm.LlamaBridge {
    native <methods>;
}
