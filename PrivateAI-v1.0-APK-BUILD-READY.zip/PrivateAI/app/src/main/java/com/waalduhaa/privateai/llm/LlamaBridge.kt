package com.waalduhaa.privateai.llm

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Thin Kotlin wrapper around native/llama_bridge.cpp, which links llama.cpp
 * and runs a quantized GGUF model entirely on-CPU (optionally NNAPI/GPU
 * offload where the device supports it). No network calls exist in this
 * class or in the native code it calls.
 *
 * The model file itself is NOT bundled in source control / this repo because
 * usable GGUF models run 300MB–4GB, which does not belong in a git repo or
 * an app store artifact. Ship it one of two ways:
 *   1. Play Asset Delivery / APK expansion file at build time, or
 *   2. First-run "Import model" flow (see MainActivity) where the user picks
 *      a .gguf file already sitting on their device via Storage Access
 *      Framework — this still requires zero network access by the app itself.
 */
object LlamaBridge {

    init {
        System.loadLibrary("private_ai_llm")
    }

    private var modelLoaded = false
    @Volatile var modelPath: String? = null
        private set

    fun init(context: Context) {
        val candidate = File(context.getExternalFilesDir(null), "models/model.gguf")
        if (candidate.exists()) {
            modelPath = candidate.absolutePath
        }
    }

    suspend fun loadModel(path: String): Boolean = withContext(Dispatchers.Default) {
        val ok = nativeLoadModel(path, /*nThreads=*/ Runtime.getRuntime().availableProcessors().coerceIn(2, 6))
        modelLoaded = ok
        if (ok) modelPath = path
        ok
    }

    fun isReady(): Boolean = modelLoaded

    suspend fun generate(
        prompt: String,
        maxTokens: Int = 256,
        onToken: (String) -> Unit
    ): String = withContext(Dispatchers.Default) {
        if (!modelLoaded) return@withContext "[No local model loaded yet. Import a .gguf model in Settings.]"
        nativeGenerate(prompt, maxTokens, onToken)
    }

    fun unload() {
        if (modelLoaded) {
            nativeUnload()
            modelLoaded = false
        }
    }

    // ---- native ----
    private external fun nativeLoadModel(path: String, nThreads: Int): Boolean
    private external fun nativeGenerate(prompt: String, maxTokens: Int, onToken: (String) -> Unit): String
    private external fun nativeUnload()
}
