package com.waalduhaa.privateai.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {

    @Insert
    suspend fun insertConversation(conversation: Conversation): Long

    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    fun getConversations(): Flow<List<Conversation>>

    @Query("UPDATE conversations SET updatedAt = :ts WHERE id = :id")
    suspend fun touchConversation(id: Long, ts: Long = System.currentTimeMillis())

    @Insert
    suspend fun insertMessage(message: ChatMessage): Long

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessages(conversationId: Long): Flow<List<ChatMessage>>

    @Query("DELETE FROM conversations WHERE id = :conversationId")
    suspend fun deleteConversation(conversationId: Long)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteMessagesFor(conversationId: Long)

    // Privacy control: full local wipe, no confirmation step needed server-side
    // because there is no server — everything the user owns lives right here.
    @Query("DELETE FROM messages")
    suspend fun wipeAllMessages()

    @Query("DELETE FROM conversations")
    suspend fun wipeAllConversations()
}
