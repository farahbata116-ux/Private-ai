package com.waalduhaa.privateai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.waalduhaa.privateai.data.AppDatabase
import com.waalduhaa.privateai.data.ChatMessage
import com.waalduhaa.privateai.data.Conversation
import com.waalduhaa.privateai.llm.LlamaBridge
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChatViewModel(private val db: AppDatabase) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating

    private val _modelReady = MutableStateFlow(LlamaBridge.isReady())
    val modelReady: StateFlow<Boolean> = _modelReady

    private var conversationId: Long = -1

    fun startOrResumeConversation() = viewModelScope.launch {
        conversationId = db.chatDao().insertConversation(Conversation(title = "New chat"))
    }

    fun importModel(path: String) = viewModelScope.launch {
        _modelReady.value = LlamaBridge.loadModel(path)
    }

    fun sendMessage(text: String) {
        if (text.isBlank() || conversationId < 0) return
        viewModelScope.launch {
            val userMsg = ChatMessage(conversationId = conversationId, role = "user", content = text)
            db.chatDao().insertMessage(userMsg)
            _messages.update { it + userMsg }

            _isGenerating.value = true
            val partial = StringBuilder()
            val reply = LlamaBridge.generate(text) { token ->
                partial.append(token)
            }
            _isGenerating.value = false

            val finalText = if (reply.isNotBlank()) reply else partial.toString()
            val assistantMsg = ChatMessage(conversationId = conversationId, role = "assistant", content = finalText)
            db.chatDao().insertMessage(assistantMsg)
            db.chatDao().touchConversation(conversationId)
            _messages.update { it + assistantMsg }
        }
    }
}
