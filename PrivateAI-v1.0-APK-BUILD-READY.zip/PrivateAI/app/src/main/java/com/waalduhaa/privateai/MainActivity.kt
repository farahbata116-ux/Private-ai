package com.waalduhaa.privateai

import android.net.Uri
import android.widget.Toast
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.waalduhaa.privateai.data.ChatMessage
import com.waalduhaa.privateai.ui.ChatViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ChatViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
                @Suppress("UNCHECKED_CAST")
                return ChatViewModel((application as PrivateAiApp).database) as T
            }
        }
    }

    private val pickModelLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { selected ->
            val copiedPath = copyModelToPrivateStorage(selected)
            if (copiedPath != null) viewModel.importModel(copiedPath)
        }
    }

    private fun copyModelToPrivateStorage(uri: Uri): String? {
        return try {
            val modelsDir = java.io.File(getExternalFilesDir(null), "models").apply { mkdirs() }
            val modelFile = java.io.File(modelsDir, "model.gguf")
            contentResolver.openInputStream(uri)?.use { input ->
                modelFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            modelFile.absolutePath
        } catch (e: Exception) {
            Toast.makeText(this, "Could not import model: ${e.message}", Toast.LENGTH_LONG).show()
            null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        viewModel.startOrResumeConversation()

        setContent {
            MaterialTheme {
                ChatScreen(
                    viewModel = viewModel,
                    onImportModel = { pickModelLauncher.launch(arrayOf("*/*")) }
                )
            }
        }
    }
}

@Composable
fun ChatScreen(viewModel: ChatViewModel, onImportModel: () -> Unit) {
    val messages by viewModel.messages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val modelReady by viewModel.modelReady.collectAsState()
    var input by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("PRIVATE AI — fully offline") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(12.dp)
        ) {
            if (!modelReady) {
                Card(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("No local model loaded yet.")
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Import a .gguf model file stored on this device. " +
                            "This never touches the network.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = onImportModel) { Text("Import model") }
                    }
                }
            }

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(messages) { msg -> MessageBubble(msg) }
                if (isGenerating) {
                    item { Text("…thinking (on-device)", style = MaterialTheme.typography.bodySmall) }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask something…") }
                )
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = {
                    viewModel.sendMessage(input)
                    input = ""
                }) {
                    Icon(Icons.Filled.Send, contentDescription = "Send")
                }
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card {
            Text(
                text = message.content,
                modifier = Modifier.padding(10.dp)
            )
        }
    }
}
