package com.waalduhaa.privateai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Wraps Android's on-device SpeechRecognizer with EXTRA_PREFER_OFFLINE set.
 * IMPORTANT CAVEAT (documented honestly, not glossed over): whether this
 * actually runs fully offline depends on the phone. Devices with Google's
 * offline speech models downloaded (Settings > System > Languages & input >
 * On-device speech recognition) will transcribe with zero network use.
 * Devices without that pack installed will either fail or silently fall back
 * to a network recognizer, depending on OEM. There is no public API to force
 * failure instead of silent fallback, so the UI should tell users to check
 * that on-device recognition is installed for a guaranteed-offline result.
 */
class VoiceInputManager(private val context: Context) {

    fun isOnDeviceRecognitionAvailable(): Boolean =
        SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ): SpeechRecognizer {
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                onResult(text)
            }
            override fun onError(error: Int) = onError("Speech recognition error code $error")
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        recognizer.startListening(intent)
        return recognizer
    }
}
