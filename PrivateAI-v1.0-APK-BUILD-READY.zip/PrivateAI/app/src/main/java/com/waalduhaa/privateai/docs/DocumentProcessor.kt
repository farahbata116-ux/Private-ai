package com.waalduhaa.privateai.docs

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Offline document text extraction, scoped honestly:
 *  - .txt / .md / .csv: fully supported here, no library needed.
 *  - .pdf: NOT implemented in this file. Reliable offline PDF text extraction
 *    needs a real parsing library (e.g. PdfBox-Android) with its own native
 *    deps — bolt on `implementation "com.tom-roush:pdfbox-android:2.0.27.0"`
 *    (fetched once from Maven Central at build time, no runtime network use)
 *    and extend this class with a PDDocument-based extractor. Left out of
 *    this initial build to avoid shipping an untested integration.
 *  - .docx: same story — would need a local docx parser (e.g. Apache POI's
 *    slimmed Android-compatible fork); not included here.
 * All processing here happens on-device via ContentResolver — nothing is
 * uploaded anywhere.
 */
class DocumentProcessor(private val context: Context) {

    suspend fun extractText(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BufferedReader(InputStreamReader(stream)).readText()
            } ?: throw IllegalStateException("Could not open document stream")
        }
    }
}
