package com.waalduhaa.privateai.privacy

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.waalduhaa.privateai.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * All settings here are stored in an AES-256-GCM encrypted preferences file
 * backed by the Android Keystore. Nothing here is ever transmitted; there is
 * no analytics SDK and no crash-reporting SDK wired into this app.
 */
class PrivacyPrefs(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "private_ai_settings",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var saveHistory: Boolean
        get() = prefs.getBoolean(KEY_SAVE_HISTORY, true)
        set(value) = prefs.edit().putBoolean(KEY_SAVE_HISTORY, value).apply()

    var preferOfflineVoice: Boolean
        get() = prefs.getBoolean(KEY_OFFLINE_VOICE, true)
        set(value) = prefs.edit().putBoolean(KEY_OFFLINE_VOICE, value).apply()

    var autoDeleteAfterDays: Int
        get() = prefs.getInt(KEY_AUTO_DELETE, 0) // 0 = never
        set(value) = prefs.edit().putInt(KEY_AUTO_DELETE, value).apply()

    suspend fun wipeEverything(db: AppDatabase) = withContext(Dispatchers.IO) {
        db.chatDao().wipeAllMessages()
        db.chatDao().wipeAllConversations()
    }

    companion object {
        private const val KEY_SAVE_HISTORY = "save_history"
        private const val KEY_OFFLINE_VOICE = "offline_voice"
        private const val KEY_AUTO_DELETE = "auto_delete_days"
    }
}
