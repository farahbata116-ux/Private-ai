package com.waalduhaa.privateai

import android.app.Application
import com.waalduhaa.privateai.data.AppDatabase
import com.waalduhaa.privateai.llm.LlamaBridge
import com.waalduhaa.privateai.privacy.PrivacyPrefs

class PrivateAiApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var privacyPrefs: PrivacyPrefs
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        privacyPrefs = PrivacyPrefs(this)
        // Model load is lazy — happens on first chat message so app launch stays fast.
        LlamaBridge.init(this)
    }

    override fun onTerminate() {
        LlamaBridge.unload()
        super.onTerminate()
    }
}
