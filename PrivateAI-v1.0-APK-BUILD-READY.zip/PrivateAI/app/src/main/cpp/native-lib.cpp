// JNI bridge between LlamaBridge.kt and llama.cpp.
// This file performs no network I/O — it only reads a local .gguf file path
// passed in from Kotlin and runs inference on-CPU via llama.cpp's public API.

#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include "llama.h"

#define LOG_TAG "PrivateAI-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
    llama_model* g_model = nullptr;
    llama_context* g_ctx = nullptr;
    const llama_vocab* g_vocab = nullptr;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_waalduhaa_privateai_llm_LlamaBridge_nativeLoadModel(
        JNIEnv* env, jobject /*thiz*/, jstring jpath, jint nThreads) {

    const char* path = env->GetStringUTFChars(jpath, nullptr);

    llama_backend_init();

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = 0; // CPU-only for maximum device compatibility;
                              // raise this if targeting devices with tested GPU offload.

    g_model = llama_model_load_from_file(path, mparams);
    env->ReleaseStringUTFChars(jpath, path);

    if (!g_model) {
        LOGE("Failed to load model — check the .gguf path/permissions.");
        return JNI_FALSE;
    }

    g_vocab = llama_model_get_vocab(g_model);

    llama_context_params cparams = llama_context_default_params();
    // 1024 rather than 2048: the Galaxy A03 ships with 2-4GB total RAM, and a
    // smaller context window meaningfully reduces peak memory use. Raise this
    // if you're building for a device with more headroom.
    cparams.n_ctx = 1024;
    cparams.n_threads = nThreads;
    cparams.n_threads_batch = nThreads;

    g_ctx = llama_init_from_model(g_model, cparams);
    if (!g_ctx) {
        LOGE("Failed to create llama context.");
        llama_model_free(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }

    LOGI("Local model loaded successfully. Fully offline inference ready.");
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_waalduhaa_privateai_llm_LlamaBridge_nativeGenerate(
        JNIEnv* env, jobject thiz, jstring jprompt, jint maxTokens, jobject onTokenCallback) {

    if (!g_ctx || !g_model) {
        return env->NewStringUTF("[Model not loaded]");
    }

    const char* promptChars = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(promptChars);
    env->ReleaseStringUTFChars(jprompt, promptChars);

    // Tokenize
    std::vector<llama_token> tokens(prompt.size() + 8);
    int n_tokens = llama_tokenize(g_vocab, prompt.c_str(), (int32_t) prompt.size(),
                                   tokens.data(), (int32_t) tokens.size(), true, true);
    if (n_tokens < 0) {
        tokens.resize(-n_tokens);
        n_tokens = llama_tokenize(g_vocab, prompt.c_str(), (int32_t) prompt.size(),
                                   tokens.data(), (int32_t) tokens.size(), true, true);
    }
    tokens.resize(n_tokens);

    llama_batch batch = llama_batch_get_one(tokens.data(), (int32_t) tokens.size());
    if (llama_decode(g_ctx, batch) != 0) {
        return env->NewStringUTF("[Decode failed]");
    }

    jclass callbackClass = env->GetObjectClass(onTokenCallback);
    jmethodID invokeMethod = env->GetMethodID(
            callbackClass, "invoke", "(Ljava/lang/Object;)Ljava/lang/Object;");

    std::string result;
    result.reserve(maxTokens * 4);

    llama_sampler* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    for (int i = 0; i < maxTokens; i++) {
        llama_token newToken = llama_sampler_sample(sampler, g_ctx, -1);

        if (llama_vocab_is_eog(g_vocab, newToken)) break;

        char buf[256];
        int len = llama_token_to_piece(g_vocab, newToken, buf, sizeof(buf), 0, true);
        std::string piece(buf, len > 0 ? len : 0);
        result += piece;

        if (onTokenCallback != nullptr) {
            jstring jpiece = env->NewStringUTF(piece.c_str());
            env->CallObjectMethod(onTokenCallback, invokeMethod, jpiece);
            env->DeleteLocalRef(jpiece);
        }

        llama_batch nextBatch = llama_batch_get_one(&newToken, 1);
        if (llama_decode(g_ctx, nextBatch) != 0) break;
    }

    llama_sampler_free(sampler);
    return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_waalduhaa_privateai_llm_LlamaBridge_nativeUnload(JNIEnv*, jobject) {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    llama_backend_free();
}
